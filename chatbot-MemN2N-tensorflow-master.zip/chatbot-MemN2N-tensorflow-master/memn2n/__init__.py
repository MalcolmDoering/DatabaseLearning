from __future__ import absolute_import
from .memn2n_dialog import *
